"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserModel = /** @class */ (function () {
    function UserModel() {
    }
    return UserModel;
}());
exports.UserModel = UserModel;
//# sourceMappingURL=model.js.map