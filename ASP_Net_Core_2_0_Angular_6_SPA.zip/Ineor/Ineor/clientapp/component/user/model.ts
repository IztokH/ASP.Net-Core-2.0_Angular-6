﻿export class UserModel {
    id: number;
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
}