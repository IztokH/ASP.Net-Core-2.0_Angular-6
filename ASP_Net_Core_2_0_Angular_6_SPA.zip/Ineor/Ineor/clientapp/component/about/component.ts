﻿import { Component } from '@angular/core';
@Component({
    selector: 'about',
    templateUrl: './app/component/about/about.html'
})
export class AboutComponent { }