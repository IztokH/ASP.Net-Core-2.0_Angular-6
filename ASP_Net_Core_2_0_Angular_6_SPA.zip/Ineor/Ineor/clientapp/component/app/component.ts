﻿import { Component } from '@angular/core';
@Component({
    selector: 'my-app',
    templateUrl: './app/component/app/app.html'
})
export class AppComponent {}